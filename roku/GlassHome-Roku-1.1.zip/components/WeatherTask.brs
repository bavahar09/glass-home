sub init()
    m.top.functionName = "doWork"
end sub

function fetch(url as string) as dynamic
    t = CreateObject("roUrlTransfer")
    t.SetCertificatesFile("common:/certs/ca-bundle.crt")
    t.InitClientCertificates()
    t.SetUrl(url)
    body = t.GetToString()
    if body = invalid or body = "" then return invalid
    return ParseJson(body)
end function

sub doWork()
    q = m.top.query
    out = {ok: false}
    if m.top.mode = "geocode" then
        t = CreateObject("roUrlTransfer")
        r = fetch("https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&name=" + t.Escape(q.name))
        if r <> invalid and r.results <> invalid and r.results.Count() > 0 then
            g = r.results[0]
            out = {ok: true, name: g.name, lat: g.latitude, lon: g.longitude}
        end if
    else if m.top.mode = "weather" then
        u = "https://api.open-meteo.com/v1/forecast?latitude=" + q.lat.ToStr() + "&longitude=" + q.lon.ToStr()
        u = u + "&current=temperature_2m,weather_code,is_day&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset"
        u = u + "&timezone=auto&forecast_days=5"
        if q.fahrenheit then u = u + "&temperature_unit=fahrenheit"
        r = fetch(u)
        if r <> invalid and r.current <> invalid then out = {ok: true, data: r}
    else if m.top.mode = "zones" then
        ' Roku clocks only know local time and UTC, so ask for each city's current UTC offset.
        offsets = []
        for each z in q.zones
            r = fetch("https://api.open-meteo.com/v1/forecast?latitude=" + z.lat.ToStr() + "&longitude=" + z.lon.ToStr() + "&timezone=" + z.tz + "&forecast_days=1&daily=sunrise")
            if r <> invalid and r.utc_offset_seconds <> invalid then offsets.Push(r.utc_offset_seconds) else offsets.Push(invalid)
        end for
        out = {ok: true, offsets: offsets}
    end if
    m.top.result = out
end sub
