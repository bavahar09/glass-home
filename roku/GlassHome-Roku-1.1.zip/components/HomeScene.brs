' Glass Home for Roku: clock, date, greeting, weather, forecast and world clocks.
' Settings live in the Roku's registry (on the device only).

sub init()
    m.reg = CreateObject("roRegistrySection", "glasshome")
    m.s = loadSettings()
    m.worldSets = [
        {label: "London · Tokyo · Sydney", zones: [{n: "London", tz: "Europe/London", lat: 51.51, lon: -0.13}, {n: "Tokyo", tz: "Asia/Tokyo", lat: 35.68, lon: 139.69}, {n: "Sydney", tz: "Australia/Sydney", lat: -33.87, lon: 151.21}]},
        {label: "New York · Paris · Dubai", zones: [{n: "New York", tz: "America/New_York", lat: 40.71, lon: -74.01}, {n: "Paris", tz: "Europe/Paris", lat: 48.86, lon: 2.35}, {n: "Dubai", tz: "Asia/Dubai", lat: 25.2, lon: 55.27}]},
        {label: "Los Angeles · Chennai · Singapore", zones: [{n: "Los Angeles", tz: "America/Los_Angeles", lat: 34.05, lon: -118.24}, {n: "Chennai", tz: "Asia/Kolkata", lat: 13.08, lon: 80.27}, {n: "Singapore", tz: "Asia/Singapore", lat: 1.35, lon: 103.82}]}
    ]
    m.bgNames = ["Day & night (automatic)", "Grand Teton, day", "Grand Teton, night", "Plain dark"]
    m.offsets = invalid
    m.sun = invalid
    m.lastMin = -1
    m.bgShown = ""

    m.tick = m.top.findNode("tick")
    m.tick.observeField("fire", "onTick")
    m.tick.control = "start"
    m.wx = m.top.findNode("wxTimer")
    m.wx.observeField("fire", "refreshWeather")
    m.wx.control = "start"
    m.rows = m.top.findNode("rows")
    m.rows.observeField("itemSelected", "onRow")

    m.top.setFocus(true)
    onTick()
    refreshWeather()
    refreshZones()
end sub

' ---------- settings ----------
function loadSettings() as object
    s = {city: "", lat: invalid, lon: invalid, name: "", h24: false, f: true, world: 0, bg: 0}
    if m.reg.Exists("s") then
        saved = ParseJson(m.reg.Read("s"))
        if saved <> invalid then
            for each k in saved
                s[k] = saved[k]
            end for
        end if
    end if
    return s
end function

sub saveSettings()
    m.reg.Write("s", FormatJson(m.s))
    m.reg.Flush()
end sub

' ---------- helpers ----------
function two(n as integer) as string
    if n < 10 then return "0" + n.ToStr()
    return n.ToStr()
end function

function hm(h as integer, mi as integer) as object
    if m.s.h24 then return {t: two(h) + ":" + two(mi), ap: ""}
    hh = h mod 12
    if hh = 0 then hh = 12
    ap = "PM"
    if h < 12 then ap = "AM"
    return {t: hh.ToStr() + ":" + two(mi), ap: ap}
end function

function deg(x as dynamic) as string
    return Cint(x).ToStr() + "°"
end function

' ---------- clock ----------
sub onTick()
    now = CreateObject("roDateTime")
    now.ToLocalTime()
    h = now.GetHours()
    mi = now.GetMinutes()
    if mi = m.lastMin then return
    m.lastMin = mi
    t = hm(h, mi)
    m.top.findNode("clock").text = t.t
    m.top.findNode("ampm").text = t.ap
    m.top.findNode("date").text = now.GetWeekday() + ", " + monthName(now.GetMonth()) + " " + now.GetDayOfMonth().ToStr()
    g = "Good night"
    if h >= 5 and h < 12 then g = "Good morning"
    if h >= 12 and h < 17 then g = "Good afternoon"
    if h >= 17 and h < 22 then g = "Good evening"
    if m.s.name <> "" then g = g + ", " + m.s.name
    m.top.findNode("greet").text = g
    drawWorld()
    setBackground(h * 60 + mi)
    ' Shift the clock a little every minute so nothing sits still on the panel.
    shift = 6
    if m.top.saver then shift = 40
    m.top.findNode("hero").translation = [((mi * 7) mod 13 - 6) * shift / 6, ((mi * 5) mod 11 - 5) * shift / 6]
end sub

function monthName(n as integer) as string
    names = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return names[n - 1]
end function

sub setBackground(mins as integer)
    want = "day"
    if m.s.bg = 0 then
        isDay = mins >= 360 and mins < 1140
        if m.sun <> invalid then isDay = mins >= m.sun[0] and mins < m.sun[1] + 30
        if not isDay then want = "night"
    else if m.s.bg = 2 then
        want = "night"
    else if m.s.bg = 3 then
        want = "dark"
    end if
    if want = m.bgShown then return
    m.bgShown = want
    bg = m.top.findNode("bg")
    if want = "dark" then
        bg.uri = ""
        m.top.backgroundColor = "0x0B0D12FF"
        m.top.backgroundURI = ""
    else
        bg.uri = "pkg:/images/teton-" + want + ".jpg"
    end if
end sub

' ---------- world clocks ----------
sub refreshZones()
    set = m.worldSets[m.s.world mod m.worldSets.Count()]
    t = CreateObject("roSGNode", "WeatherTask")
    t.mode = "zones"
    t.query = {zones: set.zones}
    t.observeField("result", "onZones")
    t.control = "RUN"
    m.zoneTask = t
end sub

sub onZones()
    r = m.zoneTask.result
    if r <> invalid and r.ok then m.offsets = r.offsets
    drawWorld()
end sub

sub drawWorld()
    holder = m.top.findNode("world")
    holder.removeChildrenIndex(holder.getChildCount(), 0)
    set = m.worldSets[m.s.world mod m.worldSets.Count()]
    utc = CreateObject("roDateTime")
    local = CreateObject("roDateTime")
    local.ToLocalTime()
    days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    for i = 0 to set.zones.Count() - 1
        x = i * 200
        name = label(UCase(set.zones[i].n), 17, "Inter-Medium", "0xFFFFFFB0")
        name.translation = [x, 0]
        holder.appendChild(name)
        tm = "--:--"
        dayTxt = ""
        if m.offsets <> invalid and m.offsets[i] <> invalid then
            z = CreateObject("roDateTime")
            z.FromSeconds(utc.AsSeconds() + m.offsets[i])
            f = hm(z.GetHours(), z.GetMinutes())
            tm = f.t + " " + f.ap
            dayTxt = "Today"
            if z.GetDayOfWeek() <> local.GetDayOfWeek() then dayTxt = days[z.GetDayOfWeek()]
        end if
        t = label(tm, 40, "Inter-Light", "0xFFFFFFFF")
        t.translation = [x, 28]
        holder.appendChild(t)
        d = label(dayTxt, 16, "Inter-Medium", "0xFFFFFF99")
        d.translation = [x, 84]
        holder.appendChild(d)
    end for
end sub

function label(text as string, size as integer, face as string, color as string) as object
    l = CreateObject("roSGNode", "Label")
    l.text = text
    l.color = color
    f = CreateObject("roSGNode", "Font")
    f.uri = "pkg:/fonts/" + face + ".ttf"
    f.size = size
    l.font = f
    return l
end function

' ---------- weather ----------
sub refreshWeather()
    if m.s.lat = invalid then
        m.top.findNode("wCity").text = "WEATHER"
        m.top.findNode("wTemp").text = "--°"
        m.top.findNode("wDesc").text = "Press OK to set your city"
        m.top.findNode("wHiLo").text = ""
        m.top.findNode("fCard").visible = false
        return
    end if
    t = CreateObject("roSGNode", "WeatherTask")
    t.mode = "weather"
    t.query = {lat: m.s.lat, lon: m.s.lon, fahrenheit: m.s.f}
    t.observeField("result", "onWeather")
    t.control = "RUN"
    m.wxTask = t
end sub

function words(c as integer) as string
    if c = 0 then return "Clear"
    if c = 1 then return "Mostly clear"
    if c = 2 then return "Partly cloudy"
    if c = 3 then return "Cloudy"
    if c = 45 or c = 48 then return "Fog"
    if c >= 51 and c <= 57 then return "Drizzle"
    if c >= 61 and c <= 67 then return "Rain"
    if c >= 71 and c <= 77 then return "Snow"
    if c >= 80 and c <= 82 then return "Showers"
    if c = 85 or c = 86 then return "Snow showers"
    if c >= 95 then return "Thunderstorms"
    return ""
end function

function minsOf(iso as string) as integer
    parts = iso.Split("T")
    if parts.Count() < 2 then return -1
    hmv = parts[1].Split(":")
    return hmv[0].ToInt() * 60 + hmv[1].ToInt()
end function

sub onWeather()
    r = m.wxTask.result
    if r = invalid or not r.ok then
        m.top.findNode("wDesc").text = "Weather unavailable - will retry"
        return
    end if
    d = r.data
    c = d.current
    dl = d.daily
    m.top.findNode("wCity").text = UCase(m.s.city)
    m.top.findNode("wTemp").text = deg(c.temperature_2m)
    m.top.findNode("wDesc").text = words(c.weather_code)
    m.top.findNode("wHiLo").text = "H " + deg(dl.temperature_2m_max[0]) + "   L " + deg(dl.temperature_2m_min[0])
    a = minsOf(dl.sunrise[0])
    b = minsOf(dl.sunset[0])
    m.sun = [a, b]
    sr = hm(a \ 60, a mod 60)
    ss = hm(b \ 60, b mod 60)
    m.top.findNode("sun").text = "Sunrise " + sr.t + " " + sr.ap + "   ·   Sunset " + ss.t + " " + ss.ap
    m.bgShown = ""
    m.lastMin = -1
    onTick()

    holder = m.top.findNode("days")
    holder.removeChildrenIndex(holder.getChildCount(), 0)
    days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    for i = 0 to dl.time.Count() - 1
        if i > 4 then exit for
        dt = CreateObject("roDateTime")
        dt.FromISO8601String(dl.time[i] + "T12:00:00Z")
        n = days[dt.GetDayOfWeek()]
        if i = 0 then n = "Today"
        x = i * 116
        l1 = label(n, 20, "Inter-Medium", "0xFFFFFFD8")
        l1.translation = [x, 0]
        holder.appendChild(l1)
        l2 = label(deg(dl.temperature_2m_max[i]), 30, "Inter-Light", "0xFFFFFFFF")
        l2.translation = [x, 40]
        holder.appendChild(l2)
        l3 = label(deg(dl.temperature_2m_min[i]) + "  " + shortWords(dl.weather_code[i]), 17, "Inter-Medium", "0xFFFFFF99")
        l3.translation = [x, 88]
        holder.appendChild(l3)
    end for
    m.top.findNode("fCard").visible = true
end sub

function shortWords(c as integer) as string
    if c <= 1 then return "Sun"
    if c <= 3 then return "Cloud"
    if c = 45 or c = 48 then return "Fog"
    if (c >= 71 and c <= 77) or c = 85 or c = 86 then return "Snow"
    if c >= 95 then return "Storm"
    return "Rain"
end function

' ---------- settings screen ----------
sub drawRows()
    content = CreateObject("roSGNode", "ContentNode")
    clock = "12-hour"
    if m.s.h24 then clock = "24-hour"
    unit = "°F"
    if not m.s.f then unit = "°C"
    city = m.s.city
    if city = "" then city = "Not set"
    name = m.s.name
    if name = "" then name = "None"
    items = ["City for weather:  " + city, "Name in the greeting:  " + name, "Clock:  " + clock, "Temperature:  " + unit, "World clocks:  " + m.worldSets[m.s.world mod m.worldSets.Count()].label, "Background:  " + m.bgNames[m.s.bg]]
    for each t in items
        it = content.createChild("ContentNode")
        it.title = t
    end for
    keep = m.rows.itemFocused
    m.rows.content = content
    if keep <> invalid and keep >= 0 then m.rows.jumpToItem = keep
end sub

sub openSettings()
    drawRows()
    m.top.findNode("settings").visible = true
    m.top.findNode("hint").visible = false
    m.rows.setFocus(true)
end sub

sub closeSettings()
    m.top.findNode("settings").visible = false
    m.top.setFocus(true)
    m.lastMin = -1
    onTick()
end sub

sub onRow()
    i = m.rows.itemSelected
    if i = 0 then
        askText("Your city (for example Detroit)", m.s.city, "city")
        return
    else if i = 1 then
        askText("Name for the greeting", m.s.name, "name")
        return
    else if i = 2 then
        m.s.h24 = not m.s.h24
    else if i = 3 then
        m.s.f = not m.s.f
        refreshWeather()
    else if i = 4 then
        m.s.world = (m.s.world + 1) mod m.worldSets.Count()
        m.offsets = invalid
        refreshZones()
    else if i = 5 then
        m.s.bg = (m.s.bg + 1) mod m.bgNames.Count()
        m.bgShown = ""
    end if
    saveSettings()
    m.lastMin = -1
    onTick()
    drawRows()
end sub

sub askText(title as string, value as string, which as string)
    kb = CreateObject("roSGNode", "StandardKeyboardDialog")
    kb.title = title
    kb.text = value
    kb.buttons = ["OK", "Cancel"]
    kb.observeField("buttonSelected", "onKeyboard")
    m.asking = which
    m.kb = kb
    m.top.dialog = kb
end sub

sub onKeyboard()
    kb = m.kb
    if kb.buttonSelected <> 0 then
        kb.close = true
        return
    end if
    v = kb.text.Trim()
    if m.asking = "name" then
        m.s.name = Left(v, 40)
        saveSettings()
        kb.close = true
        drawRows()
        m.lastMin = -1
        onTick()
        return
    end if
    if v = "" then
        m.s.city = ""
        m.s.lat = invalid
        m.s.lon = invalid
        saveSettings()
        kb.close = true
        refreshWeather()
        drawRows()
        return
    end if
    kb.title = "Looking up " + v + "..."
    t = CreateObject("roSGNode", "WeatherTask")
    t.mode = "geocode"
    t.query = {name: v}
    t.observeField("result", "onGeocode")
    t.control = "RUN"
    m.geoTask = t
end sub

sub onGeocode()
    r = m.geoTask.result
    if r = invalid or not r.ok then
        m.kb.title = "Couldn't find that city. Try another spelling."
        return
    end if
    m.s.city = r.name
    m.s.lat = r.lat
    m.s.lon = r.lon
    saveSettings()
    m.kb.close = true
    refreshWeather()
    drawRows()
end sub

' ---------- screensaver ----------
sub onSaver()
    if m.top.saver then m.top.findNode("hint").visible = false
end sub

' ---------- remote ----------
function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if m.top.saver then return false
    if m.top.findNode("settings").visible then
        if key = "back" or key = "left" then
            closeSettings()
            return true
        end if
        return false
    end if
    if key = "OK" or key = "up" or key = "down" or key = "right" or key = "options" then
        openSettings()
        return true
    end if
    return false
end function
