' Glass Home for Roku: a glass clock, weather and world-clock dashboard.
' Main() runs it as an app; RunScreenSaver() makes it a Roku screensaver
' (Settings > Theme > Screensavers > Glass Home).

sub Main(args as dynamic)
    show(false)
end sub

sub RunScreenSaver()
    show(true)
end sub

sub show(saver as boolean)
    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.setMessagePort(port)
    scene = screen.CreateScene("HomeScene")
    screen.show()
    scene.saver = saver
    while true
        msg = wait(0, port)
        if type(msg) = "roSGScreenEvent" and msg.isScreenClosed() then return
    end while
end sub
